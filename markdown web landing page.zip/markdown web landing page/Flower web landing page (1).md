<img src="happy people with flower logo template.png" style="position: absolute; top: 0; left: 0; width: 100px; height: 100px;">

 #  **FLOWER** 



###### same day delivery  |  Birthday flower    |  Gift Hamper    |New Arrivals

<img src="flower 7.jpg" style="display: block; margin: 0 auto; width: 1000px; height: 400px;">

## Hand-delivered Across Pakistan

1. Usa
2. Uk
3. Chaina
4. Germany

### Grand Moments
Adding love & beauty to every occasion

<img src="flower 8.jpg" style="position: left; margin: 0 ; width: 400px; height: 200px;"> <img src="flower 9.jpg" style="position: right; margin: 20 ; width: 400px; height: 200px;">

<img src="frank-zhang-KIE5A_tFeCs-unsplash.jpg" style="position: left; margin: 0 ; width: 400px; height: 200px;">
<img src="anthony-delanoix-urUdKCxsTUI-unsplash.jpg" style="position: right; margin: 20 ; width: 400px; height: 200px;">

## Our Products

<img src="flower 1.jpg" style="position: left; margin: 0 ; width: 400px; height: 400px;">

**PKR  8000**

<img src="flower 2.jpg" style="position: right; margin: 0 ; width: 400px; height: 400px;">

**PKR  15000**

<img src="flower 3.jpg" style="position: left; margin: 0 ; width: 400px; height: 400px;">

**PKR  10000**

<img src="flower 4.jpg" style="position: right; margin: 0 ; width: 400px; height: 400px;">

**PKR  13000**

<img src="flower 5.jpg" style="position: left; margin: 0 ; width: 400px; height: 400px;">

**PKR  11000**

<img src="flower 6.jpg" style="position: right; margin: 0 ; width: 400px; height: 400px;">

**PKR  5000**



#### Online Flowers Delivery with #1 Online Flowers shop  in Pakistan
Since time immemorial, flowers have intrigued people of all eras with their stunning beauty and enticing scents. These exquisite gifts of nature possess unbelievable characteristics, some unknown yet, even just hints of them can be ridiculously attractive. Flowers have the ability to even speak a poetry without saying a word, and thus have made an integral part of human communications since forever. At flower Pakistan, we focus on speaking those very words in the plushest of exclusive floral arrangements infused with the intention to create iconic experiences for the receivers.

With roots firm in the heritage of the century-old business of delighting millions the world over with flowers, flowers company esteemed clientele only expect and receive the very best from the world of flowers. Our floral recipes include a variety of exotic flowers from across the world, sourced from any corner, at any pain, for the pleasure of our prestigious clients. Every one of our flower arrangements is carefully put together with much love, care and skilled craftsmanship making it a piece of floral art few gifts of this world can match up to. Pick from our pre-curated, stunning floral gift hampers made to suit the different kinds of personalities of receivers. Our range go from our best seller, elegant hand-tied roses bouquet in luxury tissue to glamorous hampers that combine several romantic arrangements and high-end, organic treats.

<img src="happy people with flower logo template.png" alt="My Picture 1" float="left;" margin-left="0px;" height="300 px;" width="200 px;"> 

**Contact us:** 030001234560 
